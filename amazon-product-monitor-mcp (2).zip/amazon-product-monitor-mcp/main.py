def main():
    print("Hello from amazon-product-monitor-mcp!")


if __name__ == "__main__":
    main()
