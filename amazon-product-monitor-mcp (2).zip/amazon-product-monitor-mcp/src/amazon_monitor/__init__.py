"""Amazon Product Monitor MCP Server

一个基于 FastMCP 的 Amazon 商品监控与邮件通知服务器。
"""

__version__ = "1.0.0"
